// // -----------------Lab work-----------------------

#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) {
        data = value;
        next = NULL;
    }
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() {
        head = NULL;
    }

    // Insert at beginning
    void insertAtBeginning(int value) {
        Node* newNode = new Node(value);
        newNode->next = head;
        head = newNode;
    }

    // Insert at end
    void insertAtEnd(int value) {
        Node* newNode = new Node(value);
        if (head == NULL) {
            head = newNode;
            return;
        }

        Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }

        temp->next = newNode;
    }

    // Insert at specific position
    void insertAtPosition(int value, int position) {
        if (position == 1) {
            insertAtBeginning(value);
            return;
        }

        Node* newNode = new Node(value);
        Node* temp = head;

        for (int i = 1; temp != NULL && i < position - 1; i++) {
            temp = temp->next;
        }

        if (temp == NULL) {
            cout << "Position out of range!" << endl;
            return;
        }

        newNode->next = temp->next;
        temp->next = newNode;
    }

    // Display list
    void display() {
        if (head == NULL) {
            cout << "List is empty!" << endl;
            return;
        }

        Node* temp = head;
        cout << "Linked List: ";
        while (temp != NULL) {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }

    // Search node
    void search(int value) {
        Node* temp = head;
        int pos = 1;

        while (temp != NULL) {
            if (temp->data == value) {
                cout << "Value found at position: " << pos << endl;
                return;
            }
            temp = temp->next;
            pos++;
        }

        cout << "Value not found!" << endl;
    }

    // Delete a node
    void deleteNode(int value) {
        if (head == NULL) {
            cout << "List is empty!" << endl;
            return;
        }

        if (head->data == value) {
            Node* temp = head;
            head = head->next;
            delete temp;
            cout << "Node deleted!" << endl;
            return;
        }

        Node* temp = head;
        while (temp->next != NULL && temp->next->data != value) {
            temp = temp->next;
        }

        if (temp->next == NULL) {
            cout << "Value not found!" << endl;
            return;
        }

        Node* toDelete = temp->next;
        temp->next = temp->next->next;
        delete toDelete;
        cout << "Node deleted!" << endl;
    }

    // Update a node
    void update(int oldValue, int newValue) {
        Node* temp = head;

        while (temp != NULL) {
            if (temp->data == oldValue) {
                temp->data = newValue;
                cout << "Node updated!" << endl;
                return;
            }
            temp = temp->next;
        }

        cout << "Value not found!" << endl;
    }

    // Reverse the list
    void reverse() {
        Node* prev = NULL;
        Node* current = head;
        Node* next = NULL;

        while (current != NULL) {
            next = current->next;
            current->next = prev;
            prev = current;
            current = next;
        }

        head = prev;
        cout << "List reversed!" << endl;
    }

    // Sort the list (Ascending)
    void sortList() {
        if (head == NULL || head->next == NULL)
            return;

        for (Node* i = head; i != NULL; i = i->next) {
            for (Node* j = i->next; j != NULL; j = j->next) {
                if (i->data > j->data) {
                    int temp = i->data;
                    i->data = j->data;
                    j->data = temp;
                }
            }
        }

        cout << "List sorted!" << endl;
    }
};

// Menu
int main() {
    LinkedList list;
    int choice, value, pos, oldValue, newValue;

    while (true) {
        cout << "\n--- Singly Linked List Menu ---\n";
        cout << "1. Insert at Beginning\n";
        cout << "2. Insert at End\n";
        cout << "3. Insert at Position\n";
        cout << "4. Display List\n";
        cout << "5. Search\n";
        cout << "6. Delete Node\n";
        cout << "7. Update Node\n";
        cout << "8. Reverse List\n";
        cout << "9. Sort List\n";
        cout << "10. Exit\n";

        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            list.insertAtBeginning(value);
            break;

        case 2:
            cout << "Enter value: ";
            cin >> value;
            list.insertAtEnd(value);
            break;

        case 3:
            cout << "Enter value and position: ";
            cin >> value >> pos;
            list.insertAtPosition(value, pos);
            break;

        case 4:
            list.display();
            break;

        case 5:
            cout << "Enter value: ";
            cin >> value;
            list.search(value);
            break;

        case 6:
            cout << "Enter value to delete: ";
            cin >> value;
            list.deleteNode(value);
            break;

        case 7:
            cout << "Enter old value & new value: ";
            cin >> oldValue >> newValue;
            list.update(oldValue, newValue);
            break;

        case 8:
            list.reverse();
            break;

        case 9:
            list.sortList();
            break;

        case 10:
            cout << "Exiting...\n";
            return 0;

        default:
            cout << "Invalid choice!\n";
        }
    }
}

// -------------------------- Task # 01 ------------------------------

#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node *next;
};

void insert_at_beg(Node *&head)
{
    int value;
    cout << "Enter Value to enter: ";
    cin >> value;

    Node *newNode = new Node();
    newNode->data = value;
    newNode->next = head;
    head = newNode;

    cout << "Successfully Added." << endl;
}

void insert_at_end(Node *&head)
{
    int value;
    cout << "Enter Value to add: ";
    cin >> value;

    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL)
    {
        head = newNode;
        cout << "Successfully Added at end." << endl;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }
    temp->next = newNode;

    cout << "Successfully Added at end." << endl;
}

void insert_at_pos(Node *&head)
{
    int pos, value;
    cout << "Enter Position: ";
    cin >> pos;

    cout << "Enter Value to Add: ";
    cin >> value;

    if (pos < 1)
    {
        cout << "Invalid Position!" << endl;
        return;
    }
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;
    if (pos == 1)
    {
        newNode->next = head;
        head = newNode;
        cout << "Successfully Added." << endl;
        return;
    }
    Node* temp = head;
    for (int i = 1; i < pos - 1; i++)
    {
        if (temp == NULL)
        {
            cout << "Position out of range!" << endl;
            return;
        }
        temp = temp->next;
    }
    if (temp == NULL)
    {
        cout << "Position out of range!" << endl;
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;

    cout << "Successfully Added at Position " << pos << endl;
}

void display(Node *head)
{
    Node* temp = head;

    if (head == NULL)
    {
        cout << "List is empty!" << endl;
        return;
    }

    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL";
}
int main()
{
    int choice = 0;
    Node *head = NULL;

    while (choice != 5)
    {
        cout << "\n== Linked List ==" << endl;
        cout << "1: Add at End" << endl;
        cout << "2: Add at Beginning" << endl;
        cout << "3: Add at Position" << endl;
        cout << "4: Display All Elements" << endl;
        cout << "5: Exit" << endl;
        cout << "Your Choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            insert_at_end(head);
            break;

        case 2:
            insert_at_beg(head);
            break;

        case 3:
            insert_at_pos(head);
            break;

        case 4:
            display(head);
            break;

        case 5:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Wrong Choice!" << endl;
        }
    }

    return 0;
}

// ------------------------------- Task # 02 -------------------------------


#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node *next;
};

void insert_at_beg(Node *&head)
{
    int value;
    cout << "Enter Value to enter: ";
    cin >> value;

    Node *newNode = new Node();
    newNode->data = value;
    newNode->next = head;
    head = newNode;

    cout << "Successfully Added at Beginning." << endl;
}

void insert_at_end(Node *&head)
{
    int value;
    cout << "Enter Value to add: ";
    cin >> value;

    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL)
    {
        head = newNode;
        cout << "Successfully Added at End." << endl;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;

    cout << "Successfully Added at End." << endl;
}

void insert_at_pos(Node *&head)
{
    int pos, value;
    cout << "Enter Position: ";
    cin >> pos;

    cout << "Enter Value: ";
    cin >> value;

    if (pos < 1)
    {
        cout << "Invalid Position!" << endl;
        return;
    }

    Node* newNode = new Node();
    newNode->data = value;

    if (pos == 1)
    {
        newNode->next = head;
        head = newNode;
        cout << "Successfully Added at Position 1." << endl;
        return;
    }

    Node* temp = head;
    for (int i = 1; i < pos - 1; i++)
    {
        if (temp == NULL)
        {
            cout << "Position Out of Range!" << endl;
            return;
        }
        temp = temp->next;
    }

    if (temp == NULL)
    {
        cout << "Position Out of Range!" << endl;
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;

    cout << "Successfully Added at Position " << pos << endl;
}

void display(Node *head)
{
    if (head == NULL)
    {
        cout << "List is empty!" << endl;
        return;
    }

    Node* temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}
void searchElement(Node* head, int value)
{
    int pos = 1;
    Node* temp = head;

    while(temp != NULL)
    {
        if(temp->data == value)
        {
            cout << "Element " << value << " found at position " << pos << endl;
            return;
        }
        temp = temp->next;
        pos++;
    }

    cout << "Element " << value << " not found in the list." << endl;
}

void deletePos(Node*& head, int pos)
{
    if(head == NULL || pos < 1)
    {
        cout << "Invalid Position!" << endl;
        return;
    }

    if(pos == 1)
    {
        Node* temp = head;
        head = head->next;
        delete temp;
        cout << "Node deleted at position 1." << endl;
        return;
    }

    Node* temp = head;
    for(int i = 1; i < pos - 1; i++)
    {
        if(temp == NULL || temp->next == NULL)
        {
            cout << "Position out of range!" << endl;
            return;
        }
        temp = temp->next;
    }

    Node* delNode = temp->next;

    if(delNode == NULL)
    {
        cout << "Position out of range!" << endl;
        return;
    }

    temp->next = delNode->next;
    delete delNode;

    cout << "Node deleted at position " << pos << endl;
}

int main()
{
    Node *head = NULL;
    int choice = 0;

    while (choice != 7)
    {
        cout << "\n== Linked List Menu ==" << endl;
        cout << "1: Add at End" << endl;
        cout << "2: Add at Beginning" << endl;
        cout << "3: Add at Position" << endl;
        cout << "4: Display List" << endl;
        cout << "5: Search Element" << endl;
        cout << "6: Delete at Position" << endl;
        cout << "7: Exit" << endl;
        cout << "Your Choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            insert_at_end(head);
            break;

        case 2:
            insert_at_beg(head);
            break;

        case 3:
            insert_at_pos(head);
            break;

        case 4:
            display(head);
            break;

        case 5: {
            int value;
            cout << "Enter value to search: ";
            cin >> value;
            searchElement(head, value);
            break;
        }

        case 6: {
            int pos;
            cout << "Enter position to delete: ";
            cin >> pos;
            deletePos(head, pos);
            break;
        }

        case 7:
            cout << "Exiting..." << endl;
            break;

        default:
            cout << "Invalid Choice!" << endl;
        }
    }

    return 0;
}
