-------Task 1--------
In the first program I apply these core concepts

-> Add list from end
-> Add list from start
-> Add list from Given position

-------Task 2--------
In the first program I apply these core concepts

->Add at End
->Add at Beginning
->Add at Position
->Display List
->Search Element
->Delete at Position


--------THE END------
